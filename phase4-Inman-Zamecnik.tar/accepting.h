#ifndef accepting_h
#define accepting_h

#include "state.h"
#include "hardware.h"

static state_t*   order_received();

#endif
