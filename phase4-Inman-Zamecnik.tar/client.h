#ifndef client_h
#define client_h

#include "mySock.h"
#include "server.h"

#endif