#ifndef shipping_h
#define shipping_h

#include "state.h"

static state_t*  lost_package();
static state_t*  received();
static void      entry_to();

#endif
